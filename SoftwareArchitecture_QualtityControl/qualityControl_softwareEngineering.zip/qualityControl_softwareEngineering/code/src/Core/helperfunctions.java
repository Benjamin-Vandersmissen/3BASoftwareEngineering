package Core;

class convert{
    public static String priceToString(float price){
        return Float.toString(price);
    }
}
