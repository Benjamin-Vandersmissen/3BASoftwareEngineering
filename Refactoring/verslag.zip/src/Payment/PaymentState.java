package Payment;

public enum PaymentState {
	STARTED, OPEN, SUCCEED, FAILED, ABORTED
}
