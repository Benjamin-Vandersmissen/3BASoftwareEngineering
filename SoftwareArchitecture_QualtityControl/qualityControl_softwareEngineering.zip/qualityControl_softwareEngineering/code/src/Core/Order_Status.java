package Core;

public enum Order_Status {
	STARTED, PAYED, DELIVERED, CANCELED;
}